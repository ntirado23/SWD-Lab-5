import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PetFinderAutomation {

    public static void main(String[] args) throws InterruptedException {
     
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver.exe");

     
        WebDriver driver = new ChromeDriver();

     
        driver.get("http://petfinder.com");

      
        driver.manage().window().maximize();

      
        Thread.sleep(3000); // Wait for 3 seconds

        
        driver.quit();
    }
}
